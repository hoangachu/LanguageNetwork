# jnoty
jnoty is a jQuery plugin that show OS X's Growl like notification in web app.
Demo https://visualapps.github.io/jnoty/

![jnoty](https://github.com/visualapps/jnoty/blob/master/docs/jnoty-1.2.0.png)


